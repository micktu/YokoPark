$(document).ready(function() {
    // $(window).resize(sizeContent);

    // function sizeContent() {
    //     var newHeight = $(window).height() + "px";
    //     $(".js-fullheight").css("height", newHeight);
    //     // $(".js-top-center").each(function(){
    //     //     $(this).css("margin-top", $(this).height()/2*(-1) + "px");
    //     // });
    //     // $(".js-horiz-center").each(function(){
    //     //     $(this).css("margin-left", $(this).width()/2*(-1) + "px");
    //     // });
    // }
    // sizeContent();
    // window.setTimeout(sizeContent, 100);
    $('.js-animate-it').on('click', function(){
        if(!$(this).hasClass('animate')) {
            $(this).addClass('animate');
            $(this).parent().addClass('focus');
            window.setTimeout(endAnimation, 5000);
        } else {
            $(this).removeClass('animate');
            $(this).parent().removeClass('focus');
        }
    });
    $('.js-animate-it-long').on('click', function(){
        if(!$(this).hasClass('animate')) {
            $(this).addClass('animate');
            $(this).parent().addClass('focus');
            window.setTimeout(endAnimationLong, 9000);
        } else {
            $(this).removeClass('animate');
            $(this).parent().removeClass('focus');
        }
    });
    // scaleBg();
    // $('.waterfall-frame__flow').sprite({fps: 30, no_of_frames: 100, play_frames: 0});

    // $(window).load(function () {
    //     setTimeout(function(){
    //         $('.preloader').fadeOut('slow', function () {
    //         });
    //     },2000);
    // });


    $(window).load(function () {
        $("[class^='js-animate-it']").waitForImages(function() {
            setTimeout(function(){
                $('.preloader').fadeOut('slow', function () {
                });
            },2000);
        });
    });
});

function endAnimation() {
    var animatedBlock = $('.js-animate-it');
    $(animatedBlock).removeClass('animate');
    $(animatedBlock).parent().removeClass('focus');
}
function endAnimationLong() {
    var animatedBlock = $('.js-animate-it-long');
    $(animatedBlock).removeClass('animate');
    $(animatedBlock).parent().removeClass('focus');
}
function scaleBg() {
    var imgBg = $('.main');
    if ($(imgBg).innerWidth() > $(window).innerWidth()) {
        var scaleRatio = Math.round($(window).innerWidth()/$(imgBg).innerWidth()*10)/10;
        $('body').css('zoom', scaleRatio);
        document.body.style.zoom = scaleRatio*100 + "%";
    }
}
